"""Read-only Object/Goal provenance for formal downstream consumers.

This adds operational evidence, never scientific acceptance. Callers retain the
original F00/F01/F03, complete-training, trial and timing validators. No adapter
is installed here; no checkpoint or sealed state is opened. All returned file
maps are scoped immutable evidence, suitable for the global freeze receipt.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re


ROOT = Path(__file__).resolve().parents[2]

# Explicit candidate-only failure consumer; never modifies the original module.
import importlib.util as _startup_importlib
_startup_spec = _startup_importlib.spec_from_file_location("formal_startup_failure_candidate", Path(__file__).with_name("startup_failure_evidence.py"))
_startup = _startup_importlib.module_from_spec(_startup_spec)
_startup_spec.loader.exec_module(_startup)
SCHEMA = "formal_main_v2"
VERSION = "formal-downstream-assets-review-startup-0840-v1"
RUNTIME_VERSION = "formal-downstream-assets-v1"
P = PurePosixPath("/ssdfs/datahome/u15016/XXY_CVPR/CTI-VLA")
SOURCE = P / "snapshots/formal_main_v2_run_564be0995e"
SOURCE_SHA256 = "dd3e5450e80b8e1f05a78acf6a05daf393f7362420fd8e87a8e6f5ec03feb61e"
SOURCE_INVENTORY = "results/formal_main_v2/source/formal_main_v2_run_564be0995e.json"
FORMAL_REGISTRATION = "configs/experiments/formal_main_v2.json"
HELPER = ".local/cuda_startup_recovery_0840/formal_asset_downstream_review_startup.py"
SHARED = "scripts/review_formal_acceptance.py"
METADATA_HELPER = "scripts/ops/formal_asset_compat_review.py"
METADATA_HELPER_SHA256 = "6ad55ddac4bfb692c72e3b1a9c37f41d6d831d7d03a2f2fbbde7f3c0dcf8f46b"
COMPONENT_HELPER = "scripts/ops/formal_goal_component_review.py"
COMPONENT_HELPER_SHA256 = "f220ff71084c460b1fb66d56d63e10f0256dc1fb98874fd0f6f916c293734871"
ENTRYPOINT = "scripts/ops/formal_asset_evaluation_adapter.py"
OLD_ADAPTER = "scripts/ops/formal_evaluation_adapter.py"
OLD_ADAPTER_SHA256 = "b54dc0d87cbc10c639b0cf59475011f7a68809999862c14ebf02393e96764acd"
CONTROLLER = "scripts/ops/formal_downstream_supervisor.py"
WRAPPER = "scripts/server/run_formal_downstream.py"
SUITES = ("libero_object", "libero_goal")
ALL_SUITES = ("libero_10", "libero_spatial", *SUITES)
STAGES = ("development", "final", "collect", "full", "components")
FORBIDDEN = {".pt", ".pth", ".bin", ".safetensors", ".ckpt", ".pkl", ".pickle", ".init", ".pruned_init"}
JOB_KEYS = ("job_id", "experiment", "mode", "stage_key", "suite", "run_root", "source_root", "source_sha256",
    "invocation", "invocation_sha256", "status", "exit_code", "elapsed_seconds", "gpus", "training_seed",
    "visual_tokens", "segment_end", "runtime_compatibility", "component_compatibility")


def require(condition, message):
    if not condition:
        raise ValueError("Asset downstream review: " + message)


def same(actual, expected, label):
    require(isinstance(actual, dict) and all(actual.get(k) == v and
        (not isinstance(v, bool) or type(actual.get(k)) is bool) for k, v in expected.items()), label + " differs")


def sha_value(value):
    require(isinstance(value, str) and re.fullmatch(r"[a-f0-9]{64}", value), "invalid SHA256")
    return value


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def signature(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


class ScopedEvidence:
    """Adapt either root evidence API; exclude unrelated mutable caller reads."""
    def __init__(self, parent, *, forbidden_paths=()):
        self.parent = parent
        self.root = Path(getattr(parent, "root", getattr(parent, "project", ""))).resolve()
        require(self.root.is_dir(), "missing project evidence root")
        self.project = self.root
        self.hashes = {}
        self.files = self.hashes
        self.forbidden_paths = set(getattr(parent, "forbidden_paths", ()))
        for name in forbidden_paths:
            path = Path(name)
            self.forbidden_paths.add(path if path.is_absolute() else self.root / path)

    def path(self, name):
        path = Path(name)
        path = path if path.is_absolute() else self.root / path
        require(".." not in path.parts, "evidence traversal is forbidden before path resolution")
        require(path not in self.forbidden_paths, "final rollout state-value panel is forbidden")
        require(not (set(s.lower() for s in path.suffixes) & FORBIDDEN)
            and not any("sealed" in p.lower() or p.lower() in ("weights", "checkpoints") for p in path.parts),
            "weights and sealed states are forbidden")
        require(path.resolve() == path.absolute() and self.root in path.resolve().parents,
            "evidence must be a direct project path")
        return self.parent.path(path)

    def watch(self, name):
        path = self.path(name)
        checksum = self.parent.watch(path)
        relative = path.relative_to(self.root).as_posix()
        require(relative not in self.hashes or self.hashes[relative] == checksum, "evidence changed during review")
        self.hashes[relative] = checksum
        return checksum

    def read(self, name):
        self.watch(name)
        return json.loads(self.path(name).read_text(encoding="utf-8"))

    def relative(self, name):
        return self.path(name).relative_to(self.root).as_posix()

    def unchanged(self):
        require(all(digest(self.path(p)) == h for p, h in self.hashes.items()), "evidence changed before completion")


def load_helper(evidence, relative, expected=None):
    checksum = evidence.watch(relative)
    require(expected is None or checksum == expected, "original review helper bytes changed: " + relative)
    # Import source bytes directly: no stale pyc or ambient module reuse.
    path = evidence.path(relative)
    spec = importlib.util.spec_from_file_location("asset_downstream_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


def dependencies(evidence):
    metadata = load_helper(evidence, METADATA_HELPER, METADATA_HELPER_SHA256)
    component = load_helper(evidence, COMPONENT_HELPER, COMPONENT_HELPER_SHA256)
    shared = load_helper(evidence, SHARED)
    # The convenience entrypoint must still import precisely the pinned helpers.
    require(digest(shared._compat.__file__) == METADATA_HELPER_SHA256
        and digest(shared._component.__file__) == COMPONENT_HELPER_SHA256, "shared reviewer substituted provenance helpers")
    return shared, metadata, component


def job_identity(job):
    return {k: job[k] for k in JOB_KEYS if k in job}


def registered_job(jobs, job_id, *, suite, mode, output=None):
    matches = [j for j in jobs if j.get("job_id") == job_id]
    require(len(matches) == 1, "missing or duplicate registered job: " + str(job_id))
    job = matches[0]
    same(job, dict(experiment=SCHEMA, suite=suite, mode=mode, source_root=str(SOURCE), source_sha256=SOURCE_SHA256,
        status="COMPLETED", exit_code="0:0", gpus=1), "successful source job")
    require(type(job.get("elapsed_seconds")) is int and job["elapsed_seconds"] >= 0, "source allocation cost missing")
    require(output is None or job.get("run_root") == str(P / output), "source job output differs")
    return job


def immutable_file_map(evidence, files):
    require(isinstance(files, dict) and bool(files), "missing immutable file map")
    for path, checksum in files.items():
        require(path != "results/experiment_supervisor/state.json", "mutable supervisor state cannot be frozen as evidence")
        require(evidence.watch(path) == sha_value(checksum), "immutable evidence changed: " + path)


def _root_pull(evidence, *, saved, job, shared, required):
    """Find the original terminal pull bound by a root audit, never current state."""
    candidates = []
    for path, checksum in saved.get("evidence_sha256", {}).items():
        if path.startswith(f"results/{SCHEMA}/pulls/") and path.endswith("/receipt.json"):
            require(evidence.watch(path) == checksum, "source root pull bytes changed")
            pull = evidence.read(path)
            if any(r.get("job_id") == job["job_id"] and r.get("include_run_root") is True
                    for r in pull.get("selected_jobs", [])):
                candidates.append(path)
    require(len(candidates) == 1, "source root audit must bind exactly one terminal pull for its job")
    shared.require_pulled(evidence, candidates[0], job, required)
    return candidates[0]


def _source_scope(evidence, *, suite, inventory, jobs, review_path=None):
    require(suite in ALL_SUITES, "unknown source suite")
    shared, metadata, component = dependencies(evidence)
    require(inventory == evidence.read(SOURCE_INVENTORY) and len(inventory.get("files", {})) == 173
        and inventory.get("source_root_server") == str(SOURCE) and inventory.get("source_sha256") == SOURCE_SHA256
        and hashlib.sha256(json.dumps(inventory["files"],sort_keys=True).encode()).hexdigest() == SOURCE_SHA256,
        "source inventory differs from frozen173")
    immutable_file_map(evidence, inventory["files"])
    path = review_path or f"results/{SCHEMA}/{suite}/acceptance/root_review.json"
    require(evidence.relative(path) == f"results/{SCHEMA}/{suite}/acceptance/root_review.json", "noncanonical suite acceptance review")
    saved = evidence.read(path)
    same(saved, dict(schema=SCHEMA, kind="root_acceptance_review", status="passed", suite=suite,
        source_sha256=SOURCE_SHA256), "accepted root review")
    job = registered_job(jobs, saved.get("job_id"), suite=suite, mode="acceptance", output=saved.get("output_relative"))
    require(job_identity(saved.get("job_at_review", {})) == job_identity(job), "acceptance immutable job snapshot differs")
    require(saved.get("invocation_sha256") == job["invocation_sha256"]
        and evidence.watch(job["invocation"]) == job["invocation_sha256"], "acceptance invocation changed")
    runtime = shared.require_saved_runtime_review(evidence, saved=saved, job=job, inventory=inventory)
    goal = shared.require_saved_component_review(evidence, saved=saved, job=job, inventory=inventory, metadata_review=runtime)
    require((runtime is not None) == (suite in SUITES) and (goal is not None) == (suite == "libero_goal"), "suite provenance incomplete")
    base = saved["output_relative"]
    require(PurePosixPath(base).parent.as_posix() == f"results/{SCHEMA}/{suite}/acceptance"
        and re.fullmatch(r"attempt[0-9]{2,}", PurePosixPath(base).name), "acceptance attempt path differs")
    names = ("input_acceptance.json", "input_calls.jsonl", "operator_calls.jsonl", "resume_acceptance.json",
        "f03_calls.jsonl", "acceptance_complete.json", "f01_k128.json", "f01_k256.json", "f01_k64.json")
    require(set(names) <= set(saved.get("files", {})), "acceptance root review omits scientific receipts")
    for name, checksum in saved["files"].items():
        require(evidence.watch(base + "/" + name) == checksum, "accepted artifact changed")
    _root_pull(evidence, saved=saved, job=job, shared=shared, required=[base + "/" + name for name in names])
    f00 = evidence.read(base + "/input_acceptance.json")
    require(f00.get("status") == "passed", "F00 did not pass")
    source_names={n for n in inventory["files"] if n.startswith("src/") and n.endswith(".py")}
    source_names.update("scripts/"+n for n in ("run_formal_future.py","verify_formal_acceptance.py","eval_formal_selector_libero.py","verify_long_inputs.py"))
    sources={n:inventory["files"][n] for n in sorted(source_names)}
    require(saved.get("source_files")==sources and f00.get("source_files")==sources,"accepted training source map differs")
    spec = evidence.read(FORMAL_REGISTRATION)["suites"][suite]
    projection = dict(suite=suite, source_sha256=SOURCE_SHA256, source_inventory_sha256=evidence.watch(SOURCE_INVENTORY),
        model_manifest=str(SOURCE / spec["model_manifest"]), model_manifest_sha256=spec["model_manifest_sha256"], model_revision=spec["model_revision"],
        frozen_model_sha256=sha_value(f00.get("frozen_model_sha256")), input_acceptance_sha256=evidence.watch(base + "/input_acceptance.json"))
    require(evidence.watch(spec["model_manifest"]) == spec["model_manifest_sha256"], "accepted model manifest changed")
    if runtime is not None:
        view = metadata.expected_identity(evidence, inventory=inventory, runtime=runtime["runtime_compatibility"])["views"][suite]
        projection.update(metadata_adapter_sha256=runtime["runtime_compatibility"]["files"][metadata.ADAPTER],
            metadata_registration_sha256=runtime["runtime_compatibility"]["files"][metadata.REGISTRATION],
            metadata_loader_sha256=metadata.LOADER_SHA256, metadata_view=view)
    if goal is not None:
        projection["goal_components"] = dict(loader_sha256=component.LOADER_SHA256,
            adapter_sha256=goal["component_compatibility"]["files"][component.ADAPTER],
            registration_sha256=goal["component_compatibility"]["files"][component.REGISTRATION], mappings=goal["mappings"])
    return dict(saved=saved, job=job, review_path=evidence.relative(path), runtime=runtime, component=goal,
        projection=projection, shared=shared, sources=sources)


def review_suite_acceptance(evidence, *, suite, inventory, jobs, review_path=None):
    """Extra provenance gate called before the caller's original scientific gate."""
    scoped = ScopedEvidence(evidence)
    value = _source_scope(scoped, suite=suite, inventory=inventory, jobs=jobs, review_path=review_path)
    scoped.watch(HELPER)
    scoped.unchanged()
    result = dict(schema=SCHEMA, kind="asset_suite_acceptance_provenance", version=VERSION, status="verified", suite=suite,
        helper_sha256=scoped.watch(HELPER), acceptance_review=dict(path=value["review_path"], sha256=scoped.watch(value["review_path"])),
        acceptance_job=job_identity(value["job"]),
        shared_projection=value["projection"], shared_projection_sha256=signature(value["projection"]),
        scientific_gates_replaced=False, evidence_sha256=dict(sorted(scoped.hashes.items())))
    if value["component"] is not None:
        result["component_implementation"] = value["component"]["component_compatibility"]
    if value["runtime"] is not None:
        result["metadata_implementation"] = value["runtime"]["runtime_compatibility"]
    return result


def _pair_source(evidence, *, suite, pair, method_rows, jobs, inventory, accepted):
    from cti_vla.evaluation.formal_runtime import formal_metadata, validate_formal_receipt
    from cti_vla.evaluation.formal_trials import selector_instance_identity
    from cti_vla.evaluation.teacher_diagnostics import json_signature
    base = PurePosixPath(pair["run_root_server"]).relative_to(P).as_posix() + "/training"
    config = evidence.read(pair["path"])
    require(evidence.watch(pair["path"]) == pair["sha256"] and evidence.read(base + "/registered_config.json") == config,
        "training configuration differs from registration")
    summary = evidence.read(base + "/training_summary.json")
    same(summary, dict(schema=SCHEMA, status="completed", pair_complete=True, planned_updates_per_arm=5000,
        checkpoint_unchanged=True, test_opened=False), "complete5000 training summary")
    review_path = base + "/segment_reviews/" + str(summary.get("job_id")) + ".json"
    saved = evidence.read(review_path)
    same(saved, dict(schema=SCHEMA, kind="root_segment_review", status="passed", suite=suite,
        visual_tokens=pair["visual_tokens"], seed=pair["seed"], source_sha256=SOURCE_SHA256,
        output_relative=base, job_id=summary["job_id"], requested_segment_end=5000, completed_by_arm={"A":5000,"B":5000},
        ab_same_registered_boundary=True, resume_required=False, continuation="formal_training_complete_no_extension"), "final segment review")
    relevant = [j for j in jobs if j.get("experiment") == SCHEMA and j.get("mode") == "train" and j.get("run_root") == str(P / base)]
    snapshots = saved.get("registered_pair_jobs_at_review", [])
    require(relevant and len({j["job_id"] for j in relevant}) == len(relevant)
        and {j["job_id"]:job_identity(j) for j in relevant} == {j["job_id"]:job_identity(j) for j in snapshots}
        and len(snapshots) == len(relevant), "final segment omitted or changed registered training allocations")
    ids = {j["job_id"] for j in relevant}
    startup_failure_history = saved.get("startup_failure_history", {})
    successful_ids, failed_ids = _startup.successful_and_failed_ids({j["job_id"]: j for j in relevant}, startup_failure_history)
    for failed in relevant:
        if failed["job_id"] in failed_ids:
            _startup.require_saved(evidence, job=failed, saved=startup_failure_history[failed["job_id"]])
    if suite in SUITES:
        require(set(saved.get("runtime_compatibility_history", {})) == successful_ids, "metadata success history omits or invents an allocation")
    else:
        require(not any(k in saved for k in ("runtime_compatibility", "runtime_compatibility_review", "runtime_compatibility_history")),
            "legacy training cannot carry metadata compatibility fields")
    if suite == "libero_goal":
        require(set(saved.get("component_compatibility_history", {})) == ids, "Goal component history does not cover every allocation")
    else:
        require(not any(k in saved for k in ("component_compatibility", "component_compatibility_review", "component_compatibility_history")),
            "Object training cannot carry Goal fields")
    files = saved.get("files", {})
    require(base + "/training_summary.json" in files, "final segment omits final summary")
    immutable_file_map(evidence, files)
    last_job = registered_job(jobs,summary["job_id"],suite=suite,mode="train",output=base)
    _root_pull(evidence,saved=saved,job=last_job,shared=accepted["shared"],required=list(files))
    for job in relevant:
        if job["job_id"] in failed_ids:
            # Its failed status, untouched boundary, raw files and full Slurm bill
            # have been independently reconstructed above. It trained no sample.
            continue
        registered_job(jobs, job["job_id"], suite=suite, mode="train", output=base)
        require(job.get("training_seed") == pair["seed"] and job.get("visual_tokens") == pair["visual_tokens"],
            "training history changes pair")
        require(evidence.watch(job["invocation"]) == job["invocation_sha256"], "historical training invocation changed")
        inv = evidence.read(job["invocation"])
        require(inv.get("stage") == "train" and inv.get("stage_key") == job["stage_key"], "historical stage contract differs")
        proxy = (dict(runtime_compatibility=saved["runtime_compatibility"],
            runtime_compatibility_review=saved["runtime_compatibility_history"][job["job_id"]]) if suite in SUITES else {})
        runtime = accepted["shared"].require_saved_runtime_review(evidence, saved=proxy, job=job, inventory=inventory)
        require((runtime is not None) == (suite in SUITES), "training metadata proof missing")
        if runtime:
            require(runtime["runtime_compatibility"] == accepted["runtime"]["runtime_compatibility"], "training metadata source differs from acceptance")
        if suite == "libero_goal":
            proxy.update(component_compatibility=saved["component_compatibility"],
                component_compatibility_review=saved["component_compatibility_history"][job["job_id"]])
        goal = accepted["shared"].require_saved_component_review(evidence, saved=proxy, job=job, inventory=inventory, metadata_review=runtime)
        require((goal is not None) == (suite == "libero_goal"), "training component proof missing")
        if goal:
            require(goal["component_compatibility"] == accepted["component"]["component_compatibility"], "training component source differs from acceptance")
        if job["job_id"] == summary["job_id"]:
            require(saved.get("runtime_compatibility_review") == runtime, "latest metadata proof differs from history")
            require(saved.get("component_compatibility_review") == goal, "latest component proof differs from history")
    require(saved.get("pair_allocated_gpu_seconds") == sum(j["elapsed_seconds"] * j["gpus"] for j in relevant),
        "source training allocation costs differ")
    bindings = {}
    for row in method_rows:
        identity = row["identity"]; arm = identity["method"]
        receipt_path = base + "/" + arm + "/deployment_receipt.json"
        report_path = base + "/" + arm + "/training_report.json"
        require(row.get("receipt") == receipt_path and row.get("pair_config") == pair["path"], "method points to another training source")
        require(receipt_path in files and report_path in files, "final segment does not bind selected deployment/report")
        receipt, report = evidence.read(receipt_path), evidence.read(report_path)
        metadata = formal_metadata(receipt["metadata"])
        validate_formal_receipt(receipt, metadata)
        accepted_f01 = accepted["saved"]["output_relative"] + f"/f01_k{pair['visual_tokens']}.json"
        require(row.get("f01_report") == accepted_f01
            and receipt["f01_report_sha256"] == evidence.watch(accepted_f01)
            and metadata["input_acceptance_sha256"] == accepted["projection"]["input_acceptance_sha256"]
            and metadata["training_source_files"] == accepted["sources"], "selected receipt uses another acceptance/source")
        reconstructed = selector_instance_identity({**metadata, "selector_checkpoint_sha256":receipt["checkpoint_sha256"],
            "deployment_receipt_sha256":json_signature(receipt), "f01_report_sha256":receipt["f01_report_sha256"]})
        require(identity == reconstructed and receipt.get("pair_config") == config, "selected scientific identity differs")
        same(report, dict(status="completed", training_updates_completed=5000, next_sample_cursor=40000,
            committed_samples=40000, best_checkpoint_sha256=identity["checkpoint_sha256"],
            evaluations=receipt["evaluations"], vla_parameters_unchanged=True), "complete arm report")
        require(summary.get("arms", {}).get(arm) == report and [x.get("update") for x in receipt["evaluations"]] == list(range(0,5001,500)),
            "all11 selected validation nodes must be retained")
        expected_checkpoint = str(PurePosixPath(pair["checkpoint_root_server"]) / arm / "best.pt")
        require(row.get("checkpoint") == expected_checkpoint and report.get("best_checkpoint") == expected_checkpoint,
            "deployment checkpoint path differs")
        bindings[identity["method_id"]] = dict(suite=suite, method_id=identity["method_id"], identity=identity,
            segment_review=dict(path=review_path, sha256=evidence.watch(review_path)),
            deployment_receipt=dict(path=receipt_path, sha256=evidence.watch(receipt_path)),
            training_report=dict(path=report_path, sha256=evidence.watch(report_path)),
            registered_training_job_ids=sorted(ids, key=int))
    return bindings, [job_identity(j) for j in relevant]


def review_source_provenance(evidence, *, registration, suite, inventory, method_rows, jobs):
    """Bind selected suite methods to original acceptance and every training job.

    ``jobs`` must come from registered terminal audit snapshots, not from a new
    unverifiable method-specific list. The returned job projections are frozen
    with the proof; the mutable supervisor state is never watched or copied.
    """
    from cti_vla.evaluation.formal_trials import validate_instance_identity, baseline_instance_identity
    scoped = ScopedEvidence(evidence)
    require(registration == scoped.read(FORMAL_REGISTRATION), "registration argument differs from file")
    accepted = _source_scope(scoped, suite=suite, inventory=inventory, jobs=jobs)
    require(isinstance(method_rows, list) and method_rows, "source provenance requires explicit methods")
    ids = [validate_instance_identity(r["identity"]) for r in method_rows]
    require(len(set(ids)) == len(ids), "duplicate method source identity")
    bindings, source_jobs, groups = {}, [job_identity(accepted["job"])], {}
    for row in method_rows:
        identity = row["identity"]
        require(identity["suite"] == suite and identity["model_revision"] == accepted["projection"]["model_revision"]
            and identity["frozen_model_sha256"] == accepted["projection"]["frozen_model_sha256"]
            and identity["input_acceptance_sha256"] == accepted["projection"]["input_acceptance_sha256"], "method uses another accepted base")
        if identity["method"] in ("A","B"):
            groups.setdefault((identity["visual_tokens"], identity["training_seed"]), []).append(row)
        else:
            require(identity==baseline_instance_identity(suite=suite,method=identity["method"],visual_tokens=identity["visual_tokens"],
                model_revision=accepted["projection"]["model_revision"],frozen_model_sha256=accepted["projection"]["frozen_model_sha256"],
                source_files=accepted["sources"],input_acceptance_sha256=accepted["projection"]["input_acceptance_sha256"]),
                "baseline scientific identity changed")
            bindings[identity["method_id"]] = dict(suite=suite, method_id=identity["method_id"], identity=identity,
                acceptance_review=dict(path=accepted["review_path"], sha256=scoped.watch(accepted["review_path"])))
    for (budget,seed), rows in groups.items():
        pairs = [p for p in registration["pairs"] if (p["suite"],p["visual_tokens"],p["seed"]) == (suite,budget,seed)]
        require(len(pairs) == 1, "selected pair is not uniquely registered")
        found, history = _pair_source(scoped, suite=suite, pair=pairs[0], method_rows=rows,
            jobs=jobs, inventory=inventory, accepted=accepted)
        bindings.update(found); source_jobs.extend(history)
    scoped.watch(HELPER)
    scoped.unchanged()
    result = dict(schema=SCHEMA, kind="asset_downstream_source_provenance", version=VERSION, status="verified", suite=suite,
        helper_sha256=scoped.hashes[HELPER], source_sha256=SOURCE_SHA256,
        acceptance_review=dict(path=accepted["review_path"], sha256=scoped.watch(accepted["review_path"])),
        shared_projection=accepted["projection"],
        shared_projection_sha256=signature(accepted["projection"]), method_bindings=bindings,
        registered_source_jobs=source_jobs, scientific_gates_replaced=False,
        evidence_sha256=dict(sorted(scoped.hashes.items())))
    if accepted["component"]:
        result["component_implementation"] = accepted["component"]["component_compatibility"]
    if accepted["runtime"]:
        result["metadata_implementation"] = accepted["runtime"]["runtime_compatibility"]
    return result


def downstream_contract(evidence, *, job, invocation, source_provenance):
    """Validate the actual stage contract separately from implementation sources."""
    suite = job.get("suite")
    require(suite in SUITES and job.get("mode") in STAGES, "unknown downstream compatibility stage/suite")
    require(not any(k in obj for obj in (job,invocation) for k in ("runtime_compatibility", "component_compatibility")),
        "historical stage contract cannot replace downstream execution contract")
    value = invocation.get("downstream_asset_compatibility")
    expected = dict(schema=SCHEMA,kind="formal_downstream_asset_compatibility",version=RUNTIME_VERSION,suite=suite,
        entrypoint=ENTRYPOINT,evaluation_adapter=OLD_ADAPTER,wrapper=WRAPPER,controller=CONTROLLER,
        metadata_implementation=source_provenance.get("metadata_implementation"),legacy_stage_wrappers_executed=False)
    require(isinstance(expected["metadata_implementation"],dict),"accepted metadata implementation missing")
    if suite == "libero_goal":
        require(isinstance(source_provenance.get("component_implementation"),dict),"Goal accepted component implementation missing")
        expected["component_implementation"] = source_provenance["component_implementation"]
    else:
        require("component_implementation" not in source_provenance,"Object source cannot carry Goal implementation")
    require(isinstance(value,dict) and set(value)=={*expected,"files"},"exact downstream contract fields required")
    same(value,expected,"downstream execution contract")
    require(job.get("downstream_asset_compatibility")==value,"registered downstream job contract differs")
    files = {OLD_ADAPTER:OLD_ADAPTER_SHA256,**expected["metadata_implementation"]["files"]}
    if suite=="libero_goal": files.update(expected["component_implementation"]["files"])
    require(isinstance(value["files"],dict) and set(value["files"])=={ENTRYPOINT,CONTROLLER,WRAPPER,*files},
        "downstream support file set differs")
    for name,checksum in value["files"].items():
        require(evidence.watch(name)==sha_value(checksum) and (name not in files or files[name]==checksum),
            "downstream implementation bytes changed: "+name)
    same(invocation,dict(schema=SCHEMA,kind="formal_downstream_invocation",version="formal-downstream-root-v1",
        stage=job["mode"],stage_key=job["stage_key"],suite=suite,source_root=str(SOURCE),source_sha256=SOURCE_SHA256,
        entrypoint=ENTRYPOINT,adapter_sha256=OLD_ADAPTER_SHA256,wrapper=WRAPPER,wrapper_sha256=value["files"][WRAPPER],
        support_files=value["files"],scientific_settings_changed=False,final_values_read_locally=False),"downstream invocation")
    require(job.get("source_root")==str(SOURCE) and job.get("source_sha256")==SOURCE_SHA256,
        "downstream uses another source")
    return value


def remote_relative(value):
    require(isinstance(value,str) and "\\" not in value and ".." not in PurePosixPath(value).parts,
        "remote artifact path is malformed")
    path = PurePosixPath(value)
    require(P in path.parents,"remote artifact outside registered project")
    return path.relative_to(P).as_posix()


def read_events(evidence, path, *, shared=None, kind=None):
    evidence.watch(path)
    raw = evidence.path(path).read_bytes()
    require(raw.endswith(b"\n"),"journal is empty or has an unterminated tail")
    rows = [json.loads(line) for line in raw.splitlines()]
    times=[]
    for index,row in enumerate(rows):
        require(isinstance(row,dict),"journal row is not an object")
        if shared is not None:
            same(row,{**shared,"kind":kind,"seq":index},"journal identity/sequence")
            require(type(row.get("seq")) is int,"journal sequence must be an integer")
        moment=datetime.fromisoformat(row.get("utc", ""))
        require(moment.tzinfo is not None,"journal UTC is not timezone aware")
        times.append(moment)
    require(all(a<=b for a,b in zip(times,times[1:])),"journal times moved backwards")
    return rows,times


def _pull_files(evidence, *, path, job, required):
    """Exact terminal double-SHA transport; failure accounting is never discarded."""
    relative=evidence.relative(path)
    require(relative.startswith(f"results/{SCHEMA}/pulls/") and relative.endswith("/receipt.json"),"not a formal pull receipt")
    pull=evidence.read(path)
    same(pull,dict(schema=SCHEMA,kind="nonweight_pull",status="verified_nonweight_snapshot",final_evidence=True,
        weights_copied=False,sealed_initial_states_copied=False),"downstream stable pull")
    selected=[r for r in pull.get("selected_jobs",[]) if r.get("job_id")==job["job_id"]]
    require(len(selected)==1 and selected[0].get("include_run_root") is True
        and selected[0].get("run_root")==job["run_root"] and selected[0].get("source_sha256")==SOURCE_SHA256,
        "pull does not cover this exact downstream invocation")
    require(job.get("status") in {"COMPLETED","FAILED","CANCELLED","TIMEOUT","OUT_OF_MEMORY","NODE_FAIL","PREEMPTED","BOOT_FAIL","DEADLINE","REVOKED","SPECIAL_EXIT"}
        and type(job.get("elapsed_seconds")) is int and job["elapsed_seconds"]>=0 and job.get("gpus")==1,"downstream terminal allocation missing")
    for key in ("accounting_before","accounting_after"):
        same(pull.get(key,{}).get("jobs",{}).get(job["job_id"],{}),
            {k:job[k] for k in ("status","exit_code","elapsed_seconds")},"pull terminal accounting")
    parent=PurePosixPath(relative).parent
    before_path=(parent/"inventory_before.json").as_posix();after_path=(parent/"inventory_after.json").as_posix()
    before,after=evidence.read(before_path),evidence.read(after_path)
    require(before==after and evidence.watch(before_path)==pull.get("inventory_sha256"),"pull inventories differ")
    rows={r["relative"]:r for r in pull.get("files",[])}; original={r["relative"]:r for r in before.get("files",[])}
    require(len(rows)==len(pull.get("files",[])) and len(original)==len(before.get("files",[])),"duplicate pull file rows")
    for name in required:
        a,b=rows.get(name,{}),original.get(name,{})
        checksum=evidence.watch(name);size=evidence.path(name).stat().st_size
        for item in (a,b):
            same(item,dict(relative=name,path=str(P/name),sha256=checksum,bytes=size),"pulled artifact bytes")
            require(job["job_id"] in item.get("job_ids",[]),"artifact not assigned to this job")
        require(a.get("action") in ("same_sha_skipped","downloaded_verified"),"artifact was not SHA verified")
    return dict(path=relative,sha256=evidence.watch(relative))


def _artifact(evidence, item, *, source, destination):
    require(isinstance(item,dict) and set(item)=={"source","path","sha256","bytes"},"artifact reference fields differ")
    relative=remote_relative(destination)
    same(item,dict(source=source,path=destination,sha256=evidence.watch(relative),bytes=evidence.path(relative).stat().st_size),"artifact reference")
    return relative


def _input_relative(value):
    path=PurePosixPath(value)
    require(isinstance(value,str) and "\\" not in value and ".." not in path.parts,
        "watched input path malformed")
    if SOURCE in path.parents:return path.relative_to(SOURCE).as_posix()
    return remote_relative(value)


def _original_adapter(evidence, *, job, invocation, completion, wrapper_receipt, legacy_adapter_review):
    proof=completion.get("legacy_adapter_proof")
    require(isinstance(proof,dict) and set(proof)=={"attempt_id","status","runner_status","receipt","journal","archive_owner"},
        "missing exact original evaluation adapter proof")
    attempt=proof["attempt_id"]
    require(re.fullmatch(re.escape(job["job_id"])+r"_[a-f0-9]{32}",attempt or ""),"adapter belongs to another job")
    paths=[]
    for field,suffix in (("receipt",".json"),("journal",".jsonl")):
        paths.append(_artifact(evidence,proof[field],source=str(P/f"results/{SCHEMA}/adapter_invocations"/(attempt+suffix)),
            destination=str(PurePosixPath(job["run_root"])/"adapter_invocations"/(attempt+suffix))))
    require(completion.get("legacy_adapter_artifacts")==[proof["receipt"],proof["journal"]]
        and wrapper_receipt.get("adapter_artifacts")==completion["legacy_adapter_artifacts"],"parent wrapper did not retain original adapter bytes")
    raw=evidence.read(paths[0]);events,times=read_events(evidence,paths[1])
    expected=dict(schema=SCHEMA,kind="formal_evaluation_adapter",version="formal-evaluation-explicit-archive-resume-adapter-v2-marshal2",
        attempt_id=attempt,job_id=job["job_id"],mode="evaluate" if job["mode"] in ("development","final") else job["mode"],
        resume=invocation["resume"],output=job["run_root"],source_root=str(SOURCE),source_inventory=str(P/SOURCE_INVENTORY),
        source_inventory_sha256=evidence.watch(SOURCE_INVENTORY),frozen_source_sha256=SOURCE_SHA256,verified_frozen_file_count=173,
        adapter_path=str(P/OLD_ADAPTER),adapter_sha256=OLD_ADAPTER_SHA256,
        execution_manifest_sha256=invocation["execution_manifest_sha256"],status="returned",
        frozen_source_unchanged=True,events_path=proof["journal"]["source"],events_sha256=proof["journal"]["sha256"])
    same(raw,expected,"original adapter receipt")
    require(raw.get("registration_sha256")==signature(evidence.read(FORMAL_REGISTRATION)),"old adapter uses another scientific registration")
    require(proof["status"]==raw["status"] and proof["runner_status"]==raw.get("runner_status")
        and proof["archive_owner"]=="parent downstream wrapper; copies are verified by root after SHA pull", "adapter proof outcome differs")
    require(isinstance(legacy_adapter_review,dict) and all(legacy_adapter_review.get(k)==v for k,v in raw.items()),
        "caller must first rebuild the original adapter receipt/journal")
    require(wrapper_receipt.get("adapter_receipts")==[dict(path=proof["receipt"]["path"],status=raw["status"],runner_status=raw.get("runner_status"))],
        "parent wrapper adapter outcome differs")
    require(events[0].get("event")=="adapter_start" and events[-1].get("event")=="adapter_end"
        and all(r.get("attempt_id")==attempt and r.get("job_id")==job["job_id"] for r in events),"old adapter journal lifecycle differs")
    initial=events[0].get("identity",{})
    require(all(raw.get(k)==v for k,v in initial.items()) and initial.get("adapter_sha256")==OLD_ADAPTER_SHA256
        and events[-1].get("status")=="returned" and events[-1].get("runner_status")==raw.get("runner_status"),"old adapter start/end differs")
    enter=[r for r in events if r.get("event")=="bindings_enter"];restored=[r for r in events if r.get("event")=="bindings_restored"]
    require(len(enter)==len(restored)==1 and len(raw.get("bindings",[]))==2
        and enter[0].get("bindings")==raw["bindings"],"old adapter bindings incomplete")
    bindings=raw["bindings"]
    require(restored[0].get("original_verify_code_sha256")==bindings[0].get("original_code_sha256")
        and restored[0].get("original_loader_code_sha256")==bindings[1].get("original_code_sha256"),"old adapter restore differs")
    symbols = ["frozen_execute_code_sha256", "frozen_trial_loop_code_sha256"]
    if job["mode"] not in ("development", "final"):
        symbols += ["frozen_profiler_run_code_sha256", "frozen_profiler_collect_code_sha256"]
    for name in symbols:
        require(sha_value(raw.get(name))==initial.get(name),"old adapter changed frozen callable")
    return proof,paths,events,times


def _execution_inputs(evidence, *, invocation, contract, manifest, inventory, registration, source_provenance):
    from cti_vla.evaluation.formal_trials import validate_execution_manifest, validate_final_release
    from cti_vla.evaluation.formal_profiling import validate_profile_manifest
    old=load_helper(evidence,OLD_ADAPTER,OLD_ADAPTER_SHA256)
    argv=invocation.get("argv",[])
    require(isinstance(argv,list) and argv and all(isinstance(x,str) for x in argv),"missing original argv")
    flags=[x for x in argv if x.startswith("--")]
    require(len(flags)==len(set(flags)) and "--prepare-only" not in flags,"duplicate or preparation-only flags")
    try:args=old.parser().parse_args(argv)
    except SystemExit as exc:raise ValueError("Invalid original adapter argv") from exc
    stage=invocation["stage"];mode="evaluate" if stage in ("development","final") else stage
    suite=invocation["suite"];spec=registration["suites"][suite]
    require(argv[0]==mode and args.source_root.as_posix()==str(SOURCE) and args.project_root.as_posix()==str(P)
        and args.source_inventory.as_posix()==str(P/SOURCE_INVENTORY) and args.registration.as_posix()==str(P/FORMAL_REGISTRATION)
        and args.execution_manifest.as_posix()==invocation["execution_manifest"] and args.output.as_posix()==invocation["run_root"]
        and args.adapter_sha256==OLD_ADAPTER_SHA256 and args.resume==invocation["resume"] and args.stop_after==invocation["stop_after"]
        and args.checkpoint.as_posix()==spec["model_root_server"] and args.asset_manifest.as_posix()==str(SOURCE/spec["model_manifest"]),
        "actual execution argv changes its registered source/model/output")
    require(type(invocation.get("resume")) is bool and args.policy_watchdog_seconds == 60.
        and (args.stop_after is None or type(args.stop_after) is int and args.stop_after > 0)
        and (mode == "evaluate" or not args.resume and args.stop_after is None and args.uncontended_gpu),
        "actual execution changes the registered resume/timing scope")
    require(invocation.get("source_inventory") == str(P/SOURCE_INVENTORY)
        and invocation.get("source_inventory_sha256") == evidence.watch(SOURCE_INVENTORY)
        and invocation.get("registration_sha256") == evidence.watch(FORMAL_REGISTRATION),
        "invocation original inventory/registration differs")
    require(args.protocol.as_posix() == str(P/spec["protocol"]) and args.windows.as_posix() == str(P/spec["windows"]),
        "actual execution uses another registered data source")
    require(evidence.watch(_input_relative(args.input_acceptance.as_posix()))
        == source_provenance["shared_projection"]["input_acceptance_sha256"], "deployment changed accepted F00")
    initial = P / spec["initial_states_root"]
    if stage == "final":
        require(args.development_panel is None and args.final_registry is not None and args.sealed_final is not None
            and args.final_registry.as_posix() == str(initial/"final_registry.json")
            and args.sealed_final.as_posix() == str(initial/"sealed_final.json"), "final paths differ from registration")
    else:
        require(args.development_panel is not None and args.development_panel.as_posix() == str(initial/"development.json")
            and all(x is None for x in (args.final_registry,args.sealed_final,args.release,args.release_sha256)),
            "development/profile inputs cannot substitute final-state paths")
    require(manifest.get("suite")==suite and manifest.get("split")==("final" if stage=="final" else "development")
        and [r["identity"]["method_id"] for r in manifest.get("methods",[])]==invocation.get("method_ids"),"execution suite/method/split differs")
    validate_execution_manifest(manifest,registration_sha256=signature(registration))
    if stage=="final":
        require(args.release is not None and args.release_sha256 is not None,"final invocation lacks explicit release")
        rel=_input_relative(args.release.as_posix())
        require(evidence.watch(rel)==args.release_sha256,"final release byte SHA differs")
        release=evidence.read(rel)
        validate_final_release(release,manifest.get("global_freeze"),registration_sha256=signature(registration))
        require(release==manifest.get("release"),"actual final release differs from manifest")
    elif mode!="evaluate":
        freeze=evidence.read(_input_relative(args.global_freeze.as_posix())) if args.global_freeze else None
        validate_profile_manifest(manifest,registration,collect=mode=="collect",global_freeze=freeze)
    required={str(SOURCE/n) for n in inventory["files"]}|{str(P/n) for n in contract["files"]}
    for value in (args.source_inventory,args.registration,args.execution_manifest,args.protocol,args.windows,args.asset_manifest,
            args.input_acceptance,args.development_panel,args.release,args.global_freeze,args.panel):
        if value is not None:required.add(value.as_posix())
    require(required<=set(invocation.get("watched_files",{})),"actual invocation omits required immutable deployment inputs")
    return args


def review_invocation(evidence, *, job, invocation, wrapper_receipt, inventory, pull_receipt,
        source_provenance, legacy_adapter_review):
    """Rebuild an actual downstream proof after the original adapter auditor.

    A returned result proves only runtime provenance, not scientific completion.
    The caller must rebuild trials/profile coverage and count every allocation.
    Incomplete or failing outer compatibility proof is rejected, not repaired.
    """
    output_relative = remote_relative(job["run_root"])
    scoped=ScopedEvidence(evidence, forbidden_paths=([output_relative + "/panel.json"] if job.get("mode") == "final" else []))
    require(isinstance(source_provenance,dict) and source_provenance.get("status")=="verified"
        and source_provenance.get("kind")=="asset_downstream_source_provenance","source provenance missing")
    execution_relative=remote_relative(invocation["execution_manifest"])
    manifest=scoped.read(execution_relative)
    require(scoped.watch(execution_relative)==invocation.get("execution_manifest_sha256")
        and manifest.get("suite")==job.get("suite"),"execution manifest changed")
    registration=scoped.read(FORMAL_REGISTRATION)
    rebuilt=review_source_provenance(scoped,registration=registration,suite=job["suite"],inventory=inventory,
        method_rows=manifest["methods"],jobs=source_provenance.get("registered_source_jobs",[]))
    require(rebuilt==source_provenance,"source provenance does not rebuild from raw evidence")
    value=downstream_contract(scoped,job=job,invocation=invocation,source_provenance=rebuilt)
    _execution_inputs(scoped,invocation=invocation,contract=value,manifest=manifest,inventory=inventory,
        registration=registration,source_provenance=rebuilt)
    shared=dict(schema=SCHEMA,version=RUNTIME_VERSION,job_id=job["job_id"],invocation_sha256=job["invocation_sha256"],
        mode="evaluate" if job["mode"] in ("development","final") else job["mode"],stage=job["mode"],stage_key=job["stage_key"],
        suite=job["suite"],source_root=str(SOURCE),source_sha256=SOURCE_SHA256,
        execution_manifest_sha256=invocation["execution_manifest_sha256"])
    require(scoped.watch(job["invocation"])==job["invocation_sha256"] and scoped.read(job["invocation"])==invocation,
        "registered invocation bytes changed")
    receipt_path=f"results/{SCHEMA}/job_receipts/{job['job_id']}.json"
    require(scoped.read(receipt_path)==wrapper_receipt,"parent job receipt argument differs")
    same(wrapper_receipt,dict(schema=SCHEMA,kind="formal_downstream_job_receipt",job_id=job["job_id"],stage=job["mode"],
        stage_key=job["stage_key"],run_root=job["run_root"],source_sha256=SOURCE_SHA256,adapter_sha256=OLD_ADAPTER_SHA256,
        wrapper_sha256=value["files"][WRAPPER],stage_completed_claimed=False,
        invocation_sha256=job["invocation_sha256"],downstream_asset_compatibility=value,status="returned",exit_code=0),"parent wrapper receipt")
    base=PurePosixPath(job["run_root"])/"asset_compatibility"/job["job_id"]
    global_base=P/f"results/{SCHEMA}/downstream_asset_invocations"/job["job_id"]
    artifacts=wrapper_receipt.get("asset_compatibility_artifacts",[])
    require(len(artifacts)==3,"parent receipt must bind exactly three compatibility artifacts")
    names=("identity.json","events.jsonl","completion.json")
    paths={name:_artifact(scoped,item,source=str(global_base/name),destination=str(base/name))
        for name,item in zip(names,artifacts)}
    identity,complete=scoped.read(paths["identity.json"]),scoped.read(paths["completion.json"])
    runtime=rebuilt["metadata_implementation"]
    _,metadata,component=dependencies(scoped)
    expected_metadata=metadata.expected_identity(scoped,inventory=inventory,runtime=runtime)
    actual_metadata=identity.get("metadata_identity",{})
    require(set(actual_metadata)=={*expected_metadata,"original_loader_code_sha256","directory_verifier_code_sha256"},"metadata identity fields differ")
    same(actual_metadata,expected_metadata,"actual downstream metadata identity")
    for key in ("original_loader_code_sha256","directory_verifier_code_sha256"):sha_value(actual_metadata[key])
    component_identity=None
    if job["suite"]=="libero_goal":
        expected_component=component.expected_identity(scoped,inventory=inventory,component=rebuilt["component_implementation"])
        component_identity=identity.get("component_identity",{})
        require(set(component_identity)=={*expected_component,"original_function_code_sha256"},"Goal identity fields differ")
        same(component_identity,expected_component,"actual downstream component identity")
        require(set(component_identity["original_function_code_sha256"])==set(component.SYMBOLS),"Goal original symbols differ")
        for checksum in component_identity["original_function_code_sha256"].values():sha_value(checksum)
    else:require("component_identity" not in identity,"Object identity contains Goal evidence")
    watched={str(P/job["invocation"]):job["invocation_sha256"],**invocation.get("watched_files",{})}
    require(identity.get("watched_files")==watched,"downstream input watch map differs")
    for path,checksum in watched.items():require(scoped.watch(_input_relative(path))==sha_value(checksum),"watched deployment input changed")
    expected=dict(**shared,kind="formal_downstream_asset_identity",invocation_path=str(P/job["invocation"]),
        downstream_asset_compatibility=value,evaluation_adapter_path=str(P/OLD_ADAPTER),evaluation_adapter_sha256=OLD_ADAPTER_SHA256,
        fingerprint_marshal_version=2,metadata_identity=actual_metadata,watched_files=watched,expected_frozen_base_load_calls=1,
        base_call_evidence="Frozen original runner callsite; no model-loading or timed-call instrumentation added",legacy_stage_wrappers_executed=False)
    if component_identity is not None:expected["component_identity"]=component_identity
    require(set(identity)=={*expected,"original_adapter_run_code_sha256"},"downstream identity keys differ")
    same(identity,expected,"downstream identity");sha_value(identity["original_adapter_run_code_sha256"])
    rows,times=read_events(scoped,paths["events.jsonl"],shared=shared,kind="formal_downstream_asset_event")
    order=["downstream_asset_start","asset_metadata_compat_enter"]
    if component_identity is not None:order += ["goal_component_compat_enter"]
    order += ["legacy_adapter_start","asset_metadata_compat_load_start","asset_metadata_compat_load_complete"]
    if component_identity is not None:order += ["goal_component_load_start","goal_component_load_complete"]*2
    order += ["legacy_adapter_return"]
    if component_identity is not None:order += ["goal_component_compat_exit"]
    order += ["asset_metadata_compat_exit","downstream_asset_end"]
    require([r.get("event") for r in rows]==order,"downstream exact load/restore event sequence differs")
    single={r["event"]:r for r in rows}
    same(single["downstream_asset_start"],dict(entrypoint=ENTRYPOINT,argv=invocation["argv"],downstream_asset_compatibility=value),"downstream start")
    same(single["asset_metadata_compat_enter"],dict(identity=actual_metadata),"metadata entry")
    sha_value(single["asset_metadata_compat_enter"].get("binding_code_sha256"))
    same(single["legacy_adapter_start"],dict(identity_sha256=scoped.watch(paths["identity.json"]),
        evaluation_adapter_path=str(P/OLD_ADAPTER),original_adapter_run_code_sha256=identity["original_adapter_run_code_sha256"]),"legacy adapter entry")
    same(single["asset_metadata_compat_load_start"],dict(call_id=0,view=actual_metadata["views"][job["suite"]]),"metadata adapted request")
    view=actual_metadata["views"][job["suite"]]
    same(single["asset_metadata_compat_load_complete"],dict(call_id=0,suite=job["suite"],file_count=view["file_count"],total_bytes=view["total_bytes"]),"metadata adapted result")
    same(single["asset_metadata_compat_exit"],dict(original_loader_restored=True,directory_verifier_unchanged=True,binding_intact=True,
        original_loader_code_unchanged=True,directory_verifier_code_unchanged=True,frozen_source_and_inputs_unchanged=True,
        runner_raised=False,adapted_calls_attempted=1,adapted_calls_completed=1,passthrough_calls=0),"metadata restoration")
    if component_identity is not None:
        same(single["goal_component_compat_enter"],dict(identity=component_identity),"Goal entry")
        sha_value(single["goal_component_compat_enter"].get("binding_code_sha256"))
        for name in ("goal_component_load_start","goal_component_load_complete"):
            selected=[r for r in rows if r["event"]==name]
            for index,row in enumerate(selected):
                same(row,dict(call_id=index,mapping=component_identity["mappings"][index]),"exact Goal component mapping")
                if name.endswith("complete"):
                    require(type(row.get("state_tensor_count")) is int and row["state_tensor_count"]>0,"component state was empty")
                    sha_value(row.get("state_keys_sha256"))
        same(single["goal_component_compat_exit"],dict(original_loader_restored=True,original_function_codes_unchanged=True,binding_intact=True,
            torch_load_unchanged=True,source_inputs_unchanged=True,component_files_unchanged=True,runner_raised=False,
            component_calls_attempted=2,component_calls_completed=2,rejected_calls=0),"Goal restoration")
    end=dict(status="returned",exit_code=0,loader_bindings_restored=True,original_adapter_run_unchanged=True,
        source_inputs_unchanged=True,errors=[])
    same(single["downstream_asset_end"],dict(**end,identity_sha256=scoped.watch(paths["identity.json"])),"downstream restoration/completion")
    same(complete,dict(**shared,kind="formal_downstream_asset_completion",**end,run_root=job["run_root"],downstream_asset_compatibility=value,
        legacy_stage_wrappers_executed=False,compatibility_artifacts=artifacts[:2],completion_source=str(global_base/"completion.json"),
        completion_path=str(base/"completion.json"),scientific_completion_not_inferred=True,
        cost_scope="Nested diagnostic only; count the entire Slurm allocation once"),"compatibility completion")
    wall=complete.get("wall_seconds")
    require(type(wall) in (int,float) and math.isfinite(wall) and wall>0 and wall<=job["elapsed_seconds"]+1,
        "compatibility wall time missing or beyond allocation")
    require(datetime.fromisoformat(complete["started_utc"])<=times[0],"completion start occurs after journal")
    proof,old_paths,old_events,old_times=_original_adapter(scoped,job=job,invocation=invocation,
        completion=complete,wrapper_receipt=wrapper_receipt,legacy_adapter_review=legacy_adapter_review)
    same(single["legacy_adapter_return"],dict(legacy_adapter_proof=proof,runner_status=proof["runner_status"]),"original adapter return")
    left=times[order.index("legacy_adapter_start")];right=times[order.index("legacy_adapter_return")]
    require(left<=old_times[0]<=old_times[-1]<=right,"original adapter runs outside new compatibility context")
    for row,moment in zip(rows,times):
        if row["event"] in ("asset_metadata_compat_load_start","asset_metadata_compat_load_complete","goal_component_load_start","goal_component_load_complete"):
            require(old_times[0]<=moment<=old_times[-1],"compatibility load outside original adapter attempt")
    required=[*paths.values(),*old_paths,receipt_path]
    pull=_pull_files(scoped,path=pull_receipt,job=job,required=required)
    scoped.watch(HELPER);scoped.unchanged()
    return dict(schema=SCHEMA,kind="asset_downstream_invocation_review",version=VERSION,status="verified",suite=job["suite"],
        stage=job["mode"],stage_key=job["stage_key"],job_id=job["job_id"],invocation_sha256=job["invocation_sha256"],
        execution_manifest_sha256=invocation["execution_manifest_sha256"],downstream_asset_compatibility=value,
        helper_sha256=scoped.hashes[HELPER],source_provenance_sha256=signature(rebuilt),shared_projection_sha256=rebuilt["shared_projection_sha256"],
        legacy_adapter_attempt_id=proof["attempt_id"],event_count=len(rows),metadata_loads=1,component_loads=2 if component_identity else 0,
        loader_bindings_restored=True,source_inputs_unchanged=True,original_adapter_run_unchanged=True,
        required_pulled_files=required,pull_receipt=pull,evidence_sha256=dict(sorted(scoped.hashes.items())),
        scientific_gates_replaced=False,scientific_completion_not_inferred=True,
        cost_scope="Every Slurm allocation is counted once by the root scientific reviewer; nested compatibility timing is diagnostic only")
