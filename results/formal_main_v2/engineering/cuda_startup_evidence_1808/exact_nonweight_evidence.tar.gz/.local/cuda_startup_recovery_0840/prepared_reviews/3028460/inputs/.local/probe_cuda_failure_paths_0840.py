"""Read only registered failed-pair metadata and server checkpoint identities."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shlex, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import formal_supervisor as f
OUT='results/formal_main_v2/preflight/cuda_startup_server_paths_0840.json'
assert not (ROOT/OUT).exists()
state=f.read(f.STATE)
ids=('3028460','3028468','3028522')
jobs=[next(j for j in state['registered_jobs'] if j['job_id']==jid) for jid in ids]
assert all(j['experiment']=='formal_main_v2' and j['status']=='FAILED' and j['exit_code']=='1:0' for j in jobs)
registration=f.read(ROOT/'configs/experiments/formal_main_v2.json')
pairs=[]
for job in jobs:
    pair=next(p for p in registration['pairs'] if (p['suite'],p['visual_tokens'],p['seed'])==(job['suite'],job['visual_tokens'],job['training_seed']))
    pairs.append(dict(job_id=job['job_id'],run_root=job['run_root'],checkpoint_root=pair['checkpoint_root_server'],
        zero_start=job['job_id'] in ids[:2]))
review_name='results/formal_main_v2/libero_spatial/k64/seed23/training/segment_reviews/3025205.json'
review=f.read(ROOT/review_name)
script='''from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
pairs=PAIRS
checks=CHECKS
result={'checked_utc':datetime.now(timezone.utc).isoformat(),'pairs':[],'resume_checks':[]}
for row in pairs:
 out=dict(row)
 for key in ('run_root','checkpoint_root'):
  p=Path(row[key])
  if not str(p).startswith(('/ssdfs/datahome/u15016/XXY_CVPR/CTI-VLA/','/share/home/u15016/XXY_CVPR/CTI-VLA/')):raise ValueError('foreign path')
  if p.is_symlink():raise ValueError('symlink root')
  out[key+'_exists']=p.exists()
  out[key+'_files']=[{'relative':str(q.relative_to(p)),'bytes':q.stat().st_size} for q in sorted(p.rglob('*')) if q.is_file()] if p.exists() else []
 result['pairs'].append(out)
for spec in checks:
 p=Path(spec['path']);before=p.stat()
 with p.open('rb') as stream:
  h=hashlib.sha256()
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 after=p.stat()
 result['resume_checks'].append({'path':str(p),'sha256':h.hexdigest(),'bytes':after.st_size,'stable_during_hash':(before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino)})
print(json.dumps(result))
'''.replace('PAIRS',repr(pairs)).replace('CHECKS',repr(review['server_resume_checklist']))
command=f.SSH+[shlex.quote(f.H+'/venv/bin/python')+' -B -']
started=datetime.now(timezone.utc).isoformat()
r=subprocess.run(command,input=script,text=True,encoding='utf-8',capture_output=True)
value=dict(schema='formal_main_v2',kind='root_failed_startup_checkpoint_metadata_probe',started_utc=started,
    command=command,remote_script=script,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,
    result=json.loads(r.stdout) if r.returncode==0 else None,job_ids=list(ids),
    existing_boundary=dict(path=review_name,sha256=f.sha(ROOT/review_name)),
    helper=dict(path=Path(__file__).relative_to(ROOT).as_posix(),sha256=f.sha(Path(__file__))),
    server_only_checkpoint_hashing=True,weights_downloaded=False,GPU_jobs=0,final_states_opened=False)
with (ROOT/OUT).open('x',encoding='utf-8',newline='\n') as out:json.dump(value,out,indent=2);out.write('\n')
print(json.dumps(dict(path=OUT,sha256=f.sha(ROOT/OUT),exit_code=r.returncode,result=value['result'])))
raise SystemExit(r.returncode)
