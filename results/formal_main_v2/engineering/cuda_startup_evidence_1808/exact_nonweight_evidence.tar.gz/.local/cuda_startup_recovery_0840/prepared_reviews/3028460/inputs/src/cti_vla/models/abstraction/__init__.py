"""Shared physical packing contracts."""
