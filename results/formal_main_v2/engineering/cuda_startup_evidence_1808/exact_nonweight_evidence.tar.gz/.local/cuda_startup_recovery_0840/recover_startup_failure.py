"""Candidate root-only recovery gateway; no work occurs when imported.

execute_root is intentionally an explicit Python API, not an automation loop.
Root must publish reviewed immutable failure/repair/exclusion registrations
before calling it. Original dispatchers still own pending and sbatch outcomes.
"""
from __future__ import annotations
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL', 'PREEMPTED', 'BOOT_FAIL', 'DEADLINE', 'REVOKED', 'SPECIAL_EXIT'}
NODE_ADAPTER = '.local/scheduler_node_exclusion_0840/adapter.py'
NODE_ADAPTER_SHA = 'c439b965a5e17531e66f7874f2813589e4cdf1d42a215f7eadae7e5aa072a9c6'
IMPLEMENTATION_FILES = tuple('.local/cuda_startup_recovery_0840/' + name for name in (
    'startup_failure_evidence.py', 'recover_startup_failure.py',
    'formal_asset_supervisor_startup.py', 'review_formal_segment_startup.py',
    'formal_asset_downstream_review_startup.py'))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


failure = load(HERE / 'startup_failure_evidence.py', 'startup_recovery_evidence')


class Evidence:
    def __init__(self, root): self.root, self.hashes = Path(root).resolve(), {}
    def path(self, name):
        rel = failure.safe_relative(str(name))
        path = self.root / rel
        failure.require(path.resolve() == path.absolute(), 'symlink evidence')
        return path
    def watch(self, name):
        path = self.path(name); checksum = failure.sha(path.read_bytes())
        failure.require(str(name) not in self.hashes or self.hashes[str(name)] == checksum, 'input changed')
        self.hashes[str(name)] = checksum
        return checksum
    def read(self, name): self.watch(name); return json.loads(self.path(name).read_bytes())


def normalized_status(value):
    return str(value or '').split()[0].rstrip('+') if str(value or '').split() else ''


def build_recovery_plan(root, state, jobs, *, failed_job_id, repair_relative):
    """Pure local gate. Never relabel the failed allocation or remove history."""
    e = Evidence(root)
    failure.require(state.get('pending_submission') is None, 'pending submission must be resolved first')
    selected = [j for j in jobs if j.get('job_id') == failed_job_id]
    failure.require(len(selected) == 1, 'failed allocation is missing or duplicated')
    latest = selected[0]
    own = [j for j in jobs if j.get('experiment') == failure.SCHEMA and j.get('stage_key') == latest.get('stage_key')]
    failure.require(own and max(own, key=lambda j:j['submitted_utc'])['job_id'] == failed_job_id,
                    'pair already advanced; do not repeat the startup recovery')
    active = [j for j in jobs if j.get('experiment') == failure.SCHEMA and normalized_status(j.get('status')) not in TERMINAL]
    failure.require(len(active) < 8, 'eight project requests already reserve all slots')
    failure.require(not any(j in active for j in own), 'pair has another active or unknown allocation')
    proof = failure.require_saved(e, job=latest)
    source = e.read(failure.SOURCE)
    failure.require(e.watch(failure.SOURCE) == failure.SOURCE_PIN and len(source['files']) == 173, 'wrong frozen inventory')
    for path, checksum in source['files'].items():
        failure.require(e.watch(path) == checksum, 'live frozen source differs')
    # A content-addressed repair path is bound by the unchanged invocation's
    # repair_record field even though the old dispatcher has no separate SHA key.
    repair = e.read(repair_relative)
    failure.require(Path(repair_relative).stem == e.watch(repair_relative), 'repair filename must be its exact content SHA')
    failed_ids = {j['job_id'] for j in own if normalized_status(j.get('status')) != 'COMPLETED' or j.get('exit_code') != '0:0'}
    expected = dict(status='reviewed', stage_key=latest['stage_key'], target_source_sha256=failure.SOURCE_SHA,
        segment_end=proof['requested_segment_end'], failed_job_ids=sorted(failed_ids),
        startup_failure_reviews={failure.proof_relative(latest):e.watch(failure.proof_relative(latest))},
        recovery_implementation={path:e.watch(path) for path in IMPLEMENTATION_FILES},
        automatic_retry=False, new_attempt_limit=1)
    failure.require(all(repair.get(k) == v for k,v in expected.items()), 'repair omitted failed history or changed original target')
    failure.require(failed_ids == {failed_job_id}, 'this bounded registration covers exactly this known failure')
    if proof['runtime_failure_evidence']:
        failure.require(repair.get('runtime_compatibility') == proof['runtime_failure_evidence']['runtime_compatibility'], 'repair runtime differs')
    else:
        failure.require('runtime_compatibility' not in repair, 'Spatial cannot acquire an Object adapter')
    # Before every retry, retained mutable outputs must still be exactly the
    # pre-failure snapshot. Once a later job exists, the latest check above wins.
    for path, row in proof['evidence_bundle'].items():
        if path.startswith(proof['output_relative'] + '/'):
            failure.require(e.watch(path) == row['sha256'], 'training bytes changed since failure proof')
    if proof['completed_by_arm']['A'] == 0:
        run = Path(root) / proof['output_relative']
        failure.require(not any((run / arm).exists() for arm in ('A','B')), 'zero-start arm appeared')
    args = dict(stage='train', suite=proof['suite'], budget=proof['visual_tokens'], seed=proof['seed'],
        segment=proof['requested_segment_end'], source_inventory=Path(root)/failure.SOURCE,
        resume=True, repair_record=Path(root)/repair_relative, wall_seconds=12600)
    if proof['suite'] == 'libero_object':
        args['runtime_registration'] = Path(root)/'configs/experiments/formal_main_v2_asset_execution_v1.json'
    return dict(failed_job_id=failed_job_id, args=args, proof=proof, prior_jobs=own,
        active_job_ids=[j['job_id'] for j in active], evidence_sha256=e.hashes,
        repair_relative=repair_relative, repair_sha256=e.watch(repair_relative),
        training_boundary_advanced=False, latest_allocation_still_failed=True)


def execute_root(*, failed_job_id, repair_relative, node_registration_ref, audit_relative,
                 explicit_root_authorization=False):
    """Only root may explicitly call this after separate candidate review.

    This candidate has not been enabled in any production entrypoint. It keeps
    the original global lock, fresh accounting, remote hash gates and dispatcher
    pending transaction. A transport exception is not caught or retried.
    """
    failure.require(explicit_root_authorization is True, 'explicit root execution is required')
    f = load(ROOT / 'scripts/formal_supervisor.py', 'startup_recovery_supervisor')
    failure.require(failure.sha((ROOT / NODE_ADAPTER).read_bytes()) == NODE_ADAPTER_SHA, 'node exclusion adapter changed')
    node = load(ROOT / NODE_ADAPTER, 'startup_recovery_node_exclusion')
    with f.supervisor_lock():
        state = f.read(f.STATE)
        jobs = f.refresh(state)
        plan = build_recovery_plan(ROOT, state, jobs, failed_job_id=failed_job_id, repair_relative=repair_relative)
        args = SimpleNamespace(**plan['args'])
        dispatcher = (load(HERE / 'formal_asset_supervisor_startup.py', 'asset_startup_recovery_dispatcher')
                      if args.suite == 'libero_object' else f)
        # Ensure the node exclusion context and all old helpers use the same
        # unchanged formal_supervisor instance, not an ambient duplicate import.
        if dispatcher is not f: dispatcher.f = f
        base = dispatcher if dispatcher is not f else load(ROOT / 'scripts/ops/formal_asset_supervisor.py', 'startup_remote_hash_only')
        base.f = f
        f.verify_remote_training_progress(plan['proof']['output_relative'], plan['prior_jobs'])
        base.verify_remote_resumes(plan['proof']['server_resume_checks'])
        for rel, checksum in plan['evidence_sha256'].items():
            failure.require(f.sha(ROOT / rel) == checksum, 'recovery input changed after live server precheck')
        request = dict(kind='training', suite=args.suite, budget=args.budget, seed=args.seed,
            segment_end=args.segment, resume=True)
        with node.exclude_future_sbatch(f, request=request, registration_ref=node_registration_ref, audit_relative=audit_relative):
            dispatcher.submit(args, state, jobs)
        new = state['registered_jobs'][-1]
        failure.require(new['stage_key'] == plan['proof']['stage_key'] and new['segment_end'] == plan['proof']['requested_segment_end'], 'dispatcher returned another target')
        # Preserve FAILED historical rows and the already audited boundary.
        key = f'{args.suite}_k{args.budget}_seed{args.seed}'
        tracking = state['formal_main_progress']['parallel_execution']['pair_tracking'][key]
        failed_job = next(j for j in plan['prior_jobs'] if j['job_id'] == failed_job_id)
        tracking.update(active_job_id=new['job_id'], segment_target=args.segment,
            latest_startup_recovery_review=failure.proof_relative(failed_job),
            latest_startup_recovery_repair=repair_relative)
        state['updated_utc'] = datetime.now(timezone.utc).isoformat()
        f.write(f.STATE, state)
        return new
