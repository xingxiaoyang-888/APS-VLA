"""Read-only CUDA recovery readiness; never publishes proofs or submits work."""
from pathlib import Path
from datetime import datetime, timezone
import ast, copy, hashlib, importlib.util, json, sys

sys.dont_write_bytecode = True
R = Path('/share/home/u15016/XXY_CVPR/CTI-VLA/control_repo')
OUT = R / '.local/cuda_recovery_server_heartbeat_1808'
CAND = '.local/cuda_startup_recovery_0840/'
STATE = 'results/experiment_supervisor/state.json'
PINS = {
 CAND+'startup_failure_evidence.py':'c07c5b686d103aaabfe8a7280c62ff2a8b61fcb3ab5d07ff7592011fabbfa480',
 CAND+'recover_startup_failure.py':'a9440b5d6bc15a61901f1284267ef36850450a1a59e69c1ff672bc66dcdd7cc3',
 CAND+'formal_asset_supervisor_startup.py':'5a965024487a10feceb0356b5b0c371ab49adcb7f5b6b61f5f75ea3cd4516265',
 CAND+'review_formal_segment_startup.py':'a06069b9139d24e9ac35944559fa0918afce62a4c58d57adee63ace2c3776f4a',
 CAND+'formal_asset_downstream_review_startup.py':'0e334fee9299905c9fd60768241705548c1c8df2f1100077907e6cb0236a5ca0',
 CAND+'candidate_review.json':'520f9e0b0bea7de8153f0e97dc07d15e35757cd6f3817b53753616a3427dd5b0',
 CAND+'README.md':'9178bede89da308c918e3c76064515de7c88ce200bee8fee608df412470c8f6e',
 '.local/cuda_startup_recovery_independent_0840/independent_review.json':'7e6b2991cf4364616ee8a9c3dfa8703127373510aa9247d9fc32d247c30c2c37',
 'configs/experiments/formal_main_v2_node_exclusion_v1.json':'bb14944d4c27bc56685f1b845553a68dbff0545360e37331316d95508a12ce38',
 'scripts/ops/formal_scheduler_node_exclusion.py':'c439b965a5e17531e66f7874f2813589e4cdf1d42a215f7eadae7e5aa072a9c6',
 '.local/scheduler_node_exclusion_0840/adapter.py':'c439b965a5e17531e66f7874f2813589e4cdf1d42a215f7eadae7e5aa072a9c6',
 'scripts/formal_supervisor.py':'3e0786da690552356bbe2f56458fe19e88c90b4de079211dc652d655fe3c2e95',
 'scripts/ops/formal_autonomous_training_v1/controller.py':'acf2f41826dbae34ece3ce73e56eb3b2779ff96d45b64cc7fdbd4d92da848363',
 'scripts/ops/formal_autonomous_training_v1/backend.py':'54694bfd4c65db931a2a98574d0f4e916a262a5b4b5b4a67fd4debbc96bc0b7a',
 'scripts/ops/formal_autonomous_training_v1/worker.py':'c96f8d0de3dd36e263a4bf7c332345db2abd52dd83a9e317620e00143cf86072',
 'scripts/ops/formal_autonomous_training_v1/execution.py':'f74cd59b04bf616a29564784a07d1e36a5f31e33f565830d5b2aee905d75755b',
 'scripts/ops/server_control_transport_v1/run_server_control.py':'302a3e6d16143d5a54eb542916278a7ab2eb3c6478a55593a61584d4a7cf0af5',
 'scripts/ops/server_control_transport_v1/server_transport.py':'2b159b61977959c61df2f4b20621ca16deadaceea52ae618087bea9a05cbc464',
 'scripts/ops/server_control_transport_v1/bundle_manifest.json':'3726e3249403e3afa1d4fd1688b9f08ec9d85087812efdf297d393382c18b149',
 'configs/experiments/formal_main_v2_autonomous_execution_activation_v2.json':'7391c3bb17c36f8b0dbce540e28714ac6f721662118ddb7338d7c0288aa0bcef',
 'configs/experiments/formal_main_v2_autonomous_execution_authorization_v1.json':'b709b1a822a6e07c583166496598566408c3fb012aeeadd315746ae817b4ab4d',
 'results/formal_main_v2/preflight/cuda_startup_root_observation_0840.json':'a6bb5a481e3576f9fb87892d29e37eb6425891a5d55872a589561042384d8ef2',
 'results/formal_main_v2/source/formal_main_v2_run_564be0995e.json':'5baef5e7adc942b9d9c58eb7afe3faf69417f4d7939791997876652238a12926',
}
PROOFS = {
 '3028460':'d77e2a9b4dd9a23da41fea7611ffef20fa00c1bfdef627a456ad65902e05031f',
 '3028468':'2555c99a68778af2659d49e8ce337d84473484d66c43dfc140073e0fbdb5ccbd',
 '3028522':'e3e00f34b1cbc5e8cb83f3aad7b470373d532239efe2057d95956004cebafae5',
}
def require(value, message):
    if not value: raise ValueError(message)
def digest(raw): return hashlib.sha256(raw).hexdigest()
def load(rel, name):
    spec=importlib.util.spec_from_file_location(name,R/rel)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module
def cpu_capacity_cases(c):
    def row(i, mode='train', status='RUNNING', gpus=1, suite='libero_10', budget=128, seed=17):
        return dict(job_id=str(i),experiment='formal_main_v2',mode=mode,status=status,gpus=gpus,
                    suite=suite,visual_tokens=budget,training_seed=seed,exit_code='0:0')
    def snapshot(jobs):
        return dict(rows={j['job_id']:dict(status=j['status'],exit_code=j['exit_code'],gpus=j['gpus']) for j in jobs},
                    queue={j['job_id']:dict(status=j['status']) for j in jobs if j['status'] not in c.TERMINAL})
    results=[]
    def check(name,fn):
        require(fn(),name);results.append(dict(name=name,status='passed'))
    cpu=row(900,mode='controller',gpus=0)
    seven=[row(i,mode='engineering') for i in range(1,8)]
    check('seven_GPU_plus_confirmed_CPU0_occupies_seven',lambda:len(c.capacity(seven+[cpu],snapshot(seven+[cpu]))['occupied'])==7)
    eight=seven+[row(8,mode='development')]
    check('eight_all_modes_GPU_occupies_eight',lambda:len(c.capacity(eight+[cpu],snapshot(eight+[cpu]))['occupied'])==8)
    unknown=snapshot([cpu]);unknown['rows']={}
    check('CPU0_missing_scheduler_remains_unknown',lambda:c.capacity([cpu],unknown)['unknown']==['900'])
    pending=row(1,mode='engineering',status='PENDING')
    check('pending_engineering_reserves_GPU',lambda:c.capacity([pending],snapshot([pending]))['occupied']==['1'])
    submitted=row(1,status='SUBMITTED')
    check('submitted_reserves_pair',lambda:c.capacity([submitted],snapshot([submitted]))['active_pairs']=={'libero_10_k128_seed17':['1']})
    duplicate=[row(1),row(2)]
    check('duplicate_pair_detected',lambda:'duplicate_pair:libero_10_k128_seed17' in c.capacity(duplicate,snapshot(duplicate))['findings'])
    terminal=row(1,status='COMPLETED');drift=snapshot([terminal]);drift['rows']['1']['status']='FAILED';drift['rows']['1']['exit_code']='1:0'
    check('terminal_identity_drift_rejected',lambda:'terminal_identity_drift:1' in c.capacity([terminal],drift)['findings'])
    missing=snapshot([pending]);missing['rows']={}
    check('missing_sacct_plus_queue_not_free',lambda:c.capacity([pending],missing)['unknown']==['1'] and c.capacity([pending],missing)['occupied']==['1'])
    failed=row(1,status='FAILED');failed['exit_code']='1:0'
    check('retained_FAILED_does_not_reserve_GPU',lambda:c.capacity([failed],snapshot([failed]))['occupied']==[])
    uncertain=row(1,status='UNKNOWN')
    check('UNKNOWN_reserves_and_blocks',lambda:c.capacity([uncertain],snapshot([uncertain]))['occupied']==['1'] and c.capacity([uncertain],snapshot([uncertain]))['unknown']==['1'])
    return results

def run():
    require(Path(__file__).resolve().parent==OUT,'checker must remain in its approved candidate directory')
    evidence={}
    def read(rel,pin=None):
        require(rel!=STATE and not Path(rel).is_absolute() and '..' not in Path(rel).parts,'unsafe evidence reference')
        p=R/rel
        require(not any(x.is_symlink() for x in (p,*p.parents)),'symlink evidence')
        raw=p.read_bytes();sha=digest(raw)
        require(pin is None or pin==sha,'SHA differs: '+rel)
        require(rel not in evidence or evidence[rel]==sha,'changed input: '+rel)
        evidence[rel]=sha;return raw
    for rel,pin in PINS.items():read(rel,pin)
    inventory=json.loads(read('results/formal_main_v2/source/formal_main_v2_run_564be0995e.json'))
    require(len(inventory['files'])==173,'wrong frozen inventory count')
    for rel,pin in inventory['files'].items():read(rel,pin)
    verifier=load(CAND+'startup_failure_evidence.py','cuda_readiness_failure')
    controller=load('scripts/ops/formal_autonomous_training_v1/controller.py','cuda_readiness_controller')
    tests=cpu_capacity_cases(controller)
    state_raw=(R/STATE).read_bytes();state=json.loads(state_raw)
    cases=[]
    for jid,pin in PROOFS.items():
        prepared=CAND+'prepared_reviews/'+jid+'/review.json'
        proof=json.loads(read(prepared,pin))
        for original,row in proof['evidence_bundle'].items():
            verifier.safe_relative(original);verifier.safe_relative(row['path'])
            require(len(read(row['path'],row['sha256']))==row['bytes'],'bundle size differs')
        reader=verifier.Reader(R,proof['evidence_bundle'])
        facts=verifier.reconstruct(reader,jid)
        require(all(proof.get(k)==v for k,v in facts.items()),'proof conclusion differs')
        require(set(proof['evidence_bundle'])==set(reader.raws)|{proof['reviewer']['path']},'bundle closure differs')
        for rel in facts['retained_failure_files']:read(rel,proof['evidence_bundle'][rel]['sha256'])
        current_outputs=[]
        for rel,row in proof['evidence_bundle'].items():
            if rel.startswith(facts['output_relative']+'/'):
                read(rel,row['sha256']);current_outputs.append(rel)
        own=[copy.deepcopy(j) for j in state['registered_jobs'] if j.get('experiment')=='formal_main_v2' and j.get('stage_key')==facts['stage_key']]
        latest=max(own,key=lambda j:j['submitted_utc'])
        require(latest['job_id']==jid and latest['status']=='FAILED' and latest['exit_code']=='1:0','failed pair already advanced or changed')
        require([j['job_id'] for j in own if j['status']!='COMPLETED' or j.get('exit_code')!='0:0']==[jid],'unregistered failed history')
        require(latest['elapsed_seconds']==facts['failed_allocation_gpu_seconds'] and latest['gpus']==1,'failure cost differs')
        require(sum(j['elapsed_seconds']*j['gpus'] for j in own)==facts['pair_allocated_gpu_seconds'],'pair cost differs')
        require(latest['invocation_sha256']==facts['invocation_sha256'],'invocation drift')
        canonical=facts['output_relative']+'/startup_failure_reviews/'+jid+'.json'
        canonical_present=(R/canonical).exists()
        if canonical_present:read(canonical,pin)
        require(facts['current_allocation_new_updates']==facts['current_allocation_arm_initializations']==0,'startup side effects')
        if facts['completed_by_arm']['A']==0:
            require(not any((R/facts['output_relative']/a).exists() for a in ('A','B')),'fresh arm unexpectedly appeared')
        cases.append(dict(job_id=jid,pair=f"{facts['suite']}_k{facts['visual_tokens']}_seed{facts['seed']}",
            prepared=dict(path=prepared,sha256=pin),canonical_publication=dict(path=canonical,sha256=pin,exists=canonical_present,copy_prepared_bytes_exactly=True),
            completed_by_arm=facts['completed_by_arm'],sample_cursor=facts['next_sample_cursor'],original_target=facts['requested_segment_end'],
            failure_phase=facts['failure_phase'],current_allocation_new_updates=0,current_allocation_arm_initializations=0,
            failed_gpu_seconds=facts['failed_allocation_gpu_seconds'],pair_allocated_gpu_seconds=facts['pair_allocated_gpu_seconds'],
            frozen_bundle_files=len(proof['evidence_bundle']),raw_reconstruction_passed=True,retained_failure_files=facts['retained_failure_files'],
            current_nonweight_output_snapshot_matches=current_outputs,historical_checkpoint_proof=facts['server_resume_checks'],
            fresh_checkpoint_SHA_checked_in_this_readiness=False,runtime_failure_evidence=facts['runtime_failure_evidence'],
            registered_pair_jobs_at_observation=own))
    migrations=[]
    for name in ('startup_failure_evidence.py','recover_startup_failure.py','formal_asset_supervisor_startup.py','review_formal_segment_startup.py','formal_asset_downstream_review_startup.py'):
        rel=CAND+name;tree=ast.parse(read(rel))
        assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ROOT' for t in n.targets))
        require(ast.unparse(assignment.value)=='Path(__file__).resolve().parents[2]','unexpected root expression')
        require((R/rel).resolve().parents[2]==R,'candidate root does not resolve to server R')
        migrations.append(dict(path=rel,root_resolves_to=str(R),source_changed=False))
    require(sum(c['failed_gpu_seconds'] for c in cases)==226,'failure sum differs')
    tests.append(dict(name='all_three_real_failed_bundles_and173_current_sources_rebuilt',status='passed'))
    tests.append(dict(name='all_five_existing_candidates_resolve_ROOT_to_R_without_source_edit',status='passed'))
    selfrel=Path(__file__).resolve().relative_to(R).as_posix();read(selfrel)
    if (OUT/'requirements.json').exists():requirements=json.loads(read((OUT/'requirements.json').relative_to(R).as_posix()))
    else:raise ValueError('explicit requirements document missing')
    report=dict(schema='formal_main_v2',kind='cuda_startup_server_readiness_review',version='cuda-recovery-server-heartbeat-1808-v1',
      status='prepared_evidence_verified_recovery_and_continuous_handoff_still_blocked',
      observed_utc=datetime.now(timezone.utc).isoformat(),server_control_root=str(R),ready_for_submission=False,production_changed=False,
      root_can_publish_canonical_proofs_after_independent_rehash=True,canonical_proof_publication_is_retry_authorization=False,
      cases=cases,failed_allocated_gpu_seconds=226,source173_verified=True,migration=migrations,CPU_checks=tests,
      tests_scope='Real nonweight bundle reconstruction plus pure inherited capacity function; no submission gateway executed.',
      state_observation=dict(path=STATE,sha256_at_observation=digest(state_raw),immutable_input=False,
        pending_submission_observed=state.get('pending_submission'),root_submission_hold=state.get('autonomous_training_v1',{}).get('root_submission_hold'),
        reserved_GPU_slots=state.get('autonomous_training_v1',{}).get('reserved_GPU_slots'),
        current_blocked_pairs={c['pair']:state.get('autonomous_training_v1',{}).get('blocked_pairs',{}).get(c['pair']) for c in cases}),
      requirements=requirements,read_evidence_sha256=dict(sorted(evidence.items())),
      boundaries=dict(no_local_files=True,no_SSH_subprocess_from_checker=True,no_gpu=True,no_weight_or_checkpoint_tensor_read=True,
                      no_final_states=True,no_sacct_or_squeue_calls=True,no_state_or_production_write=True,no_Git=True,
                      only_new_report_in_candidate_directory=True))
    # Fail closed if any immutable input drifted during reconstruction.
    for rel,pin in list(evidence.items()):read(rel,pin)
    output=OUT/'readiness_review.json'
    with output.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(dict(output=str(output),sha256=digest(output.read_bytes()),checks_passed=len(tests),case_count=len(cases),
      failed_gpu_seconds=226,ready_for_submission=False,evidence_count=len(evidence)),ensure_ascii=False))
if __name__=='__main__':run()
