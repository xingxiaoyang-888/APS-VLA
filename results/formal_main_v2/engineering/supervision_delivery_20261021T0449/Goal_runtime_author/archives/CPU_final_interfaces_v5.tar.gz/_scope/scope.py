from pathlib import Path
Path('/share/home/u15016/XXY_CVPR/CTI-VLA/control_repo/.local/goal_remaining5_runtime_20261021T0449/CPU_final_interfaces_v5/_scope/EXECUTED').write_text('BAD')
