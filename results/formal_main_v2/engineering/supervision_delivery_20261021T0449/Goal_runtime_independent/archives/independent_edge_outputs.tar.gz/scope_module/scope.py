from pathlib import Path
Path('/share/home/u15016/XXY_CVPR/CTI-VLA/control_repo/.local/goal_remaining5_independent_20261021T0449/runtime_source_CPU/independent_edge_outputs/scope_module/executed_marker').write_text("inert CPU sentinel")
